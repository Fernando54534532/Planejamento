import express from 'express';
import session from 'express-session';
import path from 'path';
import { fileURLToPath } from 'url';

// Importação dos módulos de rotas do sistema
import authRoutes from './routes/authRoute.js';
import userRoutes from './routes/userRoute.js';
import adminRoutes from './routes/adminRoute.js';

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Configuração do motor de visualização HTML/EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middlewares globais para decodificação de requisições e arquivos estáticos
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Configuração obrigatória da sessão exigida pelo projeto (Armazenamento em Cookies de Sessão)
app.use(session({
    secret: 'chave-secreta-meajudaaqui-uno',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false } // Define como true caso utilize HTTPS
}));

// Ativação das malhas de rotas mapeadas
app.use(authRoutes);
app.use(userRoutes);
app.use(adminRoutes);

// Middleware global para captura de erros de rotas inexistentes (Erro 404)
app.use((req, res) => {
    res.status(404).render('error', {
        title: "Página Não Encontrada - 404",
        message: "O endereço que você está tentando acessar não existe ou foi movido na plataforma MeAjudaAqui."
    });
});

const PORT = 5000;
app.listen(PORT, '127.0.0.1', () => {
    console.log(`================================================================`);
    console.log(`🚀 SERVIDOR EXECUTANDO COM SUCESSO`);
    console.log(`🔗 Interface do Sistema: http://localhost:${PORT}`);
    console.log(`================================================================`);
});