export const authMiddleware = (req, res, next) => {
    if (req.session && req.session.user) {
        return next();
    }
    // Caso não haja sessão ativa, redireciona para login com mensagem via Query String
    return res.redirect('/login?error=Acesso restrito. Faça login para continuar.');
};

export const adminMiddleware = (req, res, next) => {
    if (req.session && req.session.user && req.session.user.role === 'admin') {
        return next();
    }
    // Erro 403 Personalizado: renderiza direto uma página de erro ou redireciona
    return res.status(403).render('error', { 
        title: "Acesso Negado - Código 403", 
        message: "Você não possui permissões administrativas para acessar esta área técnica do sistema." 
    });
};