import { Router } from 'express';
import ticketController from '../controllers/ticketControllers.js';
import { authMiddleware, adminMiddleware } from '../middlewares/authMiddleware.js';

const router = Router();

// Todas as rotas deste arquivo exigem que o usuário esteja logado E seja admin
router.use(authMiddleware);
router.use(adminMiddleware);

router.get('/admin/dashboard', ticketController.showAdminDashboard);
router.get('/admin/chamados/:id', ticketController.showTicketDetail);
router.post('/admin/chamados/:id/status', ticketController.handleUpdateStatus);

export default router;