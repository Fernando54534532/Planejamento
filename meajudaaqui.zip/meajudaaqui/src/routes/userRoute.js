import { Router } from 'express';
import ticketController from '../controllers/ticketControllers.js';
import { authMiddleware } from '../middlewares/authMiddleware.js';

const router = Router();

router.use(authMiddleware); // Todas as rotas deste arquivo exigem login
router.get('/chamados', ticketController.showUserDashboard);
router.get('/chamados/novo', ticketController.showCreateForm);
router.post('/chamados/novo', ticketController.handleCreateTicket);

export default router;