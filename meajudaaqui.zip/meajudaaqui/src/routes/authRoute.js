import { Router } from 'express';
import authController from '../controllers/authControllers.js';

const router = Router();

router.get('/', authController.showHome);
router.get('/login', authController.showLogin);
router.post('/login', authController.handleLogin);
router.get('/cadastro', authController.showRegister);
router.post('/cadastro', authController.handleRegister);
router.get('/logout', authController.handleLogout);

export default router;