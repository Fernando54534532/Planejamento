// Base de dados de usuários em memória (Simulação)
const users = [
    // Usuário administrador padrão pré-cadastrado para testes
    {
        id: "1",
        nome: "Carlos Agente",
        email: "carlos.agente@unochapeco.edu.br",
        senha: "123", // Em produção usaria hash (Ex: bcrypt)
        role: "admin"
    }
];

class UserRepository {
    async findByEmail(email) {
        return users.find(u => u.email === email) || null;
    }

    async findById(id) {
        return users.find(u => u.id === id) || null;
    }

    async create(userData) {
        const newUser = {
            id: String(users.length + 1),
            ...userData,
            role: "comum" // Todo cadastro via interface web nasce como usuário comum
        };
        users.push(newUser);
        return newUser;
    }
}

export default new UserRepository();