// Base de dados de chamados em memória (Simulação)
const tickets = [
    {
        id: "001",
        titulo: "Computador não liga",
        descricao: "Computador do laboratório 3 não responde ao botão de ligar.",
        categoria: "Hardware",
        prioridade: "Alta",
        status: "Aberto",
        dataCriacao: "20/05/2026",
        usuarioId: "2", // Vinculado a um usuário teste comum
        setor: "Laboratório 3",
        patrimonio: "PC-LAB3-042",
        solicitanteNome: "João Silva",
        setorSolicitante: "Acadêmico"
    }
];

class TicketRepository {
    async findAll() {
        return tickets;
    }

    async findById(id) {
        return tickets.find(t => t.id === id) || null;
    }

    async findByUserId(userId) {
        return tickets.filter(t => t.usuarioId === userId);
    }

    async create(ticketData) {
        const nextId = String(tickets.length + 1).padStart(3, '0');
        const newTicket = {
            id: nextId,
            status: "Aberto",
            dataCriacao: new Date().toLocaleDateString('pt-BR'),
            ...ticketData
        };
        tickets.push(newTicket);
        return newTicket;
    }

    async updateStatus(id, newStatus) {
        const ticket = tickets.find(t => t.id === id);
        if (ticket) {
            ticket.status = newStatus;
            return ticket;
        }
        return null;
    }
}

export default new TicketRepository();