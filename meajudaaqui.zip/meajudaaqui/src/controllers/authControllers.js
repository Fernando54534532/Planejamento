import authService from '../services/authService.js';

class AuthController {
    showHome(req, res) {
        res.redirect('/login');
    }

    showLogin(req, res) {
        const error = req.query.error || null;
        res.render('login', { error });
    }

    async handleLogin(req, res) {
        try {
            const { email, senha } = req.body;
            const userSessionData = await authService.login(email, senha);
            
            req.session.user = userSessionData;
            
            if (userSessionData.role === 'admin') {
                return res.redirect('/admin/dashboard');
            }
            return res.redirect('/chamados');
        } catch (error) {
            res.render('login', { error: error.message });
        }
    }

    showRegister(req, res) {
        res.render('cadastro', { error: null, success: null });
    }

    async handleRegister(req, res) {
        try {
            const { nome, matricula, email, senha, confirmarSenha } = req.body;
            await authService.register(nome, matricula, email, senha, confirmarSenha);
            res.render('cadastro', { error: null, success: "Conta criada com sucesso! Faça login." });
        } catch (error) {
            res.render('cadastro', { error: error.message, success: null });
        }
    }

    handleLogout(req, res) {
        req.session.destroy(() => {
            res.redirect('/login');
        });
    }
}

export default new AuthController();