import ticketService from '../services/ticketService.js';

class TicketController {
    async showUserDashboard(req, res) {
        try {
            const userTickets = await ticketService.getTicketsForUser(req.session.user.id);
            
            // Contadores lógicos para os cards do protótipo 3
            const abertos = userTickets.filter(t => t.status === 'Aberto').length;
            const emAtendimento = userTickets.filter(t => t.status === 'Em atendimento').length;
            const resolvidos = userTickets.filter(t => t.status === 'Resolvido').length;
            const urgentes = userTickets.filter(t => t.prioridade === 'Crítica' || t.prioridade === 'Alta').length;

            res.render('user_dashboard', { 
                user: req.session.user, 
                tickets: userTickets,
                metrics: { abertos, emAtendimento, resolvidos, urgentes }
            });
        } catch (error) {
            res.status(500).render('error', { title: "Erro Interno", message: error.message });
        }
    }

    showCreateForm(req, res) {
        res.render('novo_chamado', { user: req.session.user, error: null });
    }

    async handleCreateTicket(req, res) {
        try {
            const { titulo, descricao, categoria, prioridade, setor, patrimonio } = req.body;
            await ticketService.createTicket({
                titulo,
                descricao,
                categoria,
                prioridade,
                setor,
                patrimonio,
                usuarioId: req.session.user.id,
                solicitanteNome: req.session.user.nome,
                setorSolicitante: "Acadêmico"
            });
            res.redirect('/chamados');
        } catch (error) {
            res.render('novo_chamado', { user: req.session.user, error: error.message });
        }
    }

    async showAdminDashboard(req, res) {
        try {
            const allTickets = await ticketService.getAllTicketsForAdmin();
            res.render('admin_dashboard', { user: req.session.user, tickets: allTickets });
        } catch (error) {
            res.status(500).render('error', { title: "Erro Interno", message: error.message });
        }
    }

    async showTicketDetail(req, res) {
        try {
            const ticket = await ticketService.getTicketById(req.params.id);
            res.render('detalhe_chamado', { user: req.session.user, ticket });
        } catch (error) {
            res.status(404).render('error', { title: "Não Encontrado", message: error.message });
        }
    }

    async handleUpdateStatus(req, res) {
        try {
            const { status } = req.body;
            await ticketService.updateTicketStatus(req.params.id, status, req.session.user.role);
            res.redirect(`/admin/chamados/${req.params.id}`);
        } catch (error) {
            res.status(400).render('error', { title: "Operação Inválida", message: error.message });
        }
    }
}

export default new TicketController();