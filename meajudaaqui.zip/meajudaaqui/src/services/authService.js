import userRepository from '../repositories/userRepository.js';

class AuthService {
    async login(email, senha) {
        if (!email || !senha) {
            throw new Error("E-mail institucional e senha são obrigatórios.");
        }

        const user = await userRepository.findByEmail(email);
        if (!user || user.senha !== senha) {
            throw new Error("Credenciais inválidas ou usuário não cadastrado.");
        }

        // Retorna os dados do usuário omitindo a senha por segurança
        return { id: user.id, nome: user.nome, email: user.email, role: user.role };
    }

    async register(nome, matricula, email, senha, confirmarSenha) {
        if (!nome || !matricula || !email || !senha) {
            throw new Error("Todos os campos do formulário são de preenchimento obrigatório.");
        }

        if (!email.endsWith("@unochapeco.edu.br")) {
            throw new Error("É obrigatório utilizar um e-mail institucional da Unochapecó.");
        }

        if (senha !== confirmarSenha) {
            throw new Error("A confirmação de senha não confere com a senha digitada.");
        }

        const existingUser = await userRepository.findByEmail(email);
        if (existingUser) {
            throw new Error("Este e-mail institucional já encontra-se cadastrado.");
        }

        return await userRepository.create({ nome, matricula, email, senha });
    }
}

export default new AuthService();