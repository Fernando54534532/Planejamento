import ticketRepository from '../repositories/ticketRepository.js';

class TicketService {
    async getTicketsForUser(userId) {
        return await ticketRepository.findByUserId(userId);
    }

    async getAllTicketsForAdmin() {
        return await ticketRepository.findAll();
    }

    async getTicketById(id) {
        const ticket = await ticketRepository.findById(id);
        if (!ticket) throw new Error("Chamado técnico não encontrado.");
        return ticket;
    }

    async createTicket(ticketData) {
        if (!ticketData.titulo || !ticketData.descricao || !ticketData.categoria || !ticketData.prioridade) {
            throw new Error("Os campos Título, Descrição, Categoria e Prioridade são obrigatórios.");
        }
        return await ticketRepository.create(ticketData);
    }

    async updateTicketStatus(id, status, userRole) {
        if (userRole !== 'admin') {
            throw new Error("Acesso negado. Apenas agentes de suporte podem alterar o status.");
        }

        const validStatuses = ["Aberto", "Em atendimento", "Pendente", "Resolvido", "Recusado"];
        if (!validStatuses.includes(status)) {
            throw new Error("O status informado é inválido para o fluxo de trabalho.");
        }

        const updatedTicket = await ticketRepository.updateStatus(id, status);
        if (!updatedTicket) throw new Error("Não foi possível atualizar o chamado especificado.");
        return updatedTicket;
    }
}

export default new TicketService();